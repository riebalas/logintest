package orangehrm;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class login {
    private WebDriver driver;
    private login login;

    @BeforeAll
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver"); // Set the path to your chromedriver executable
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        login = new login(driver);
    }

    @AfterAll
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void testLoginSuccess() {
        login.login("Admin", "admin123");

    }

    @Test
    public void testLoginFailure() {
        login.login("InvalidUser", "InvalidPassword");
        String errorMessage = login.getErrorMessage();
        Assert.assertEquals(errorMessage, "Invalid credentials");
    }
}

