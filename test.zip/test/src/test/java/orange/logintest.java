package orange;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class logintest {
    private WebDriver driver;
    private logintest logintest;

    @BeforeAll
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver"); // Set the path to your chromedriver executable
        driver = new ChromeDriver();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        logintest = new logintest(driver);
    }

    @AfterAll
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void testLoginSuccess() {
        logintest.login("Admin", "admin123");
        // Add assertions based on the behavior you expect after a successful login
    }

    @Test
    public void testLoginFailure() {
        logintest.login("InvalidUser", "InvalidPassword");
        String errorMessage = logintest.getErrorMessage();
        Assert.assertEquals(errorMessage, "Invalid credentials");
    }
}

